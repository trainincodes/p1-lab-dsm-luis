module.exports = function createDatabaseConnection() {
    const Sequelize = require("sequelize");
    
    const config = {
      database: "test",
      username: "root",
      password: "",
      host: "localhost",
      dialect: "mysql"
    };
  
    const sequelize = new Sequelize(config);
  
    return sequelize;
  };
  